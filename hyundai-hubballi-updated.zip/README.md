# Hyundai Hubballi Enquiry Website — Updated Version

## Files
- `index.html` — complete responsive GitHub Pages website.

## What changed
- Premium dark-blue hero section and clear enquiry calls to action.
- Hyundai model cards (Creta, Venue, Exter, i20 and Aura).
- Lifestyle image of an adult woman beside a vehicle.
- Mobile-responsive layout.
- Enquiry form asks for model, budget and buying timeline.
- Form creates a pre-filled WhatsApp message to +91 98804 34680.
- No database or automatic message sending; the visitor must press Send in WhatsApp.
- Independent-service disclaimer included.

## Publish on GitHub Pages
1. Open https://github.com/webd380-sudo/hubballi-hyundai-leads
2. Open the repository's `index.html`.
3. Before replacing it, download a copy of the current file as a backup.
4. Select the pencil/Edit icon, replace the full contents with the new `index.html` contents, then choose **Commit changes**.
   - Alternatively, choose **Add file → Upload files** and upload this `index.html`, confirming replacement if prompted.
5. Wait 1–3 minutes, then open https://webd380-sudo.github.io/hubballi-hyundai-leads/ and refresh.
6. Test model buttons, required form fields, and WhatsApp message on a phone.

## Images and brand note
Car images link to image files hosted on Hyundai India's website; the lifestyle image is hosted by Unsplash. They load from those external sites, so they need an internet connection and could change or stop loading. For long-term reliability, verify image usage rights and upload approved image files into the repository. This site is not an official Hyundai website or dealership unless separately authorised.
